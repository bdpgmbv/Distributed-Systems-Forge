package com.vyshaliprabananthlal.ecommerce_event_mesh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceEventMeshApplicationTests {

	@Test
	void contextLoads() {
	}

}
