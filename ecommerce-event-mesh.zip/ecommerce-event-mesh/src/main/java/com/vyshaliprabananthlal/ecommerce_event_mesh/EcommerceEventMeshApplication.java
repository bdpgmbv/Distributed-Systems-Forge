package com.vyshaliprabananthlal.ecommerce_event_mesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceEventMeshApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceEventMeshApplication.class, args);
	}

}
