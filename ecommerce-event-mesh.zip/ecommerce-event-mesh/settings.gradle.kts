rootProject.name = "ecommerce-event-mesh"
