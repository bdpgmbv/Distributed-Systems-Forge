package com.vyshaliprabananthlal.resilience_forge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResilienceForgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResilienceForgeApplication.class, args);
	}

}
