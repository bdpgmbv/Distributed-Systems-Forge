package com.vyshaliprabananthlal.resilience_forge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResilienceForgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
