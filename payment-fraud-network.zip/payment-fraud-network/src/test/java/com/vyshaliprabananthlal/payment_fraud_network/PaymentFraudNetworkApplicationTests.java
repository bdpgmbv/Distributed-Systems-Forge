package com.vyshaliprabananthlal.payment_fraud_network;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentFraudNetworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
