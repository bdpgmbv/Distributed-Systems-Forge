package com.vyshaliprabananthlal.payment_fraud_network;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentFraudNetworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentFraudNetworkApplication.class, args);
	}

}
