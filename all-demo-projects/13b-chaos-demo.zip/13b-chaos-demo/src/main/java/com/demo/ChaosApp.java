package com.demo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class ChaosApp { public static void main(String[] a) { SpringApplication.run(ChaosApp.class, a); } }